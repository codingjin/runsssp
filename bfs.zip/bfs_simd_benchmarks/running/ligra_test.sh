#! /usr/bin/bash

set -x
#./ligra_run.sh pokec /data/zpeng/pokec/soc-pokec 
#./ligra_run.sh livejournal /data/zpeng/livejournal/livejournal
#./ligra_run.sh rmat24 /data/zpeng/rmat24/rmat24 
#./ligra_run.sh road_usa /sciclone/scr-mlt/zpeng01/road_usa/road_usa -s 
./ligra_run.sh twt /data/zpeng/twt/out.twitter 
#./ligra_run.sh rmat27 /data/zpeng/rmat27/rmat27
#./ligra_run.sh friendster /data/zpeng/friendster/friendster 


set +x
