#! /usr/bin/bash
set -x
#./galois_run.sh pokec /data/zpeng/pokec/soc-pokec
#./galois_run.sh livejournal /data/zpeng/livejournal/livejournal
#./galois_run.sh rmat24 /data/zpeng/rmat24/rmat24
#./galois_run.sh road_usa /sciclone/scr-mlt/zpeng01/road_usa/road_usa -symmetricGraph
#./galois_run.sh twt /data/zpeng/twt/out.twitter
#./galois_run.sh rmat27 ~/data/rmat27/rmat27
./galois_run.sh friendster /data/zpeng/friendster/friendster

set +x

