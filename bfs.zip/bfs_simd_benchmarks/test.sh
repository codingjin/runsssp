#!/bin/bash 


echo pasa123 | sudo su
sync; echo 1 > /proc/sys/vm/drop_caches
echo never >/sys/kernel/mm/transparent_hugepage/enabled 
echo 0 > /proc/sys/kernel/numa_balancing
./sssp /mnt/ssd_b/data/test0.8b.txt  8192 64 64 24


sync; echo 1 > /proc/sys/vm/drop_caches
echo always >/sys/kernel/mm/transparent_hugepage/enabled
echo 0 > /proc/sys/kernel/numa_balancing
./sssp /mnt/ssd_b/data/test0.8b.txt  8192 64 64 24

sync; echo 1 > /proc/sys/vm/drop_caches
echo never >/sys/kernel/mm/transparent_hugepage/enabled
echo 1 > /proc/sys/kernel/numa_balancing
./sssp /mnt/ssd_b/data/test0.8b.txt  8192 64 64 24

sync; echo 1 > /proc/sys/vm/drop_caches
echo always >/sys/kernel/mm/transparent_hugepage/enabled
echo 0 > /proc/sys/kernel/numa_balancing
./sssp /mnt/ssd_b/data/test0.8b.txt  8192 64 64 24


sync; echo 1 > /proc/sys/vm/drop_caches
echo never >/sys/kernel/mm/transparent_hugepage/enabled
echo 0 > /proc/sys/kernel/numa_balancing
./sssp /mnt/ssd_b/data/test0.8b.txt  8192 64 64 24


sync; echo 1 > /proc/sys/vm/drop_caches
echo always >/sys/kernel/mm/transparent_hugepage/enabled
echo 0 > /proc/sys/kernel/numa_balancing
./sssp /mnt/ssd_b/data/test0.8b.txt  8192 64 64 24

sync; echo 1 > /proc/sys/vm/drop_caches
echo never >/sys/kernel/mm/transparent_hugepage/enabled
echo 1 > /proc/sys/kernel/numa_balancing
./sssp /mnt/ssd_b/data/test0.8b.txt  8192 64 64 24

sync; echo 1 > /proc/sys/vm/drop_caches
echo always >/sys/kernel/mm/transparent_hugepage/enabled
echo 0 > /proc/sys/kernel/numa_balancing
./sssp /mnt/ssd_b/data/test0.8b.txt  8192 64 64 24


sync; echo 1 > /proc/sys/vm/drop_caches
echo never >/sys/kernel/mm/transparent_hugepage/enabled
echo 0 > /proc/sys/kernel/numa_balancing
./sssp /mnt/ssd_b/data/test0.8b.txt  8192 64 64 24


sync; echo 1 > /proc/sys/vm/drop_caches
echo always >/sys/kernel/mm/transparent_hugepage/enabled
echo 0 > /proc/sys/kernel/numa_balancing
./sssp /mnt/ssd_b/data/test0.8b.txt  8192 64 64 24

sync; echo 1 > /proc/sys/vm/drop_caches
echo never >/sys/kernel/mm/transparent_hugepage/enabled
echo 1 > /proc/sys/kernel/numa_balancing
./sssp /mnt/ssd_b/data/test0.8b.txt  8192 64 64 24

sync; echo 1 > /proc/sys/vm/drop_caches
echo always >/sys/kernel/mm/transparent_hugepage/enabled
echo 0 > /proc/sys/kernel/numa_balancing
./sssp /mnt/ssd_b/data/test0.8b.txt  8192 64 64 24

